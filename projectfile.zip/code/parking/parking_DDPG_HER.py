from gymnasium.wrappers import RecordVideo
import eval_parking
import highway_env
import argparse
import os
import random
import time

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from utils import MyReplayBuffer
from utils import HER_play_back
from utils import MyReward
from torch.utils.tensorboard import SummaryWriter
import sys
from tqdm.notebook import trange


def parse_args():
    """parse arguments. You can add other arguments if needed."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--exp-name", type=str, default=os.path.basename(__file__).rstrip(".py"),
                        help="the name of this experiment")
    parser.add_argument("--total-timesteps", type=int, default=100000,
                        help="total timesteps of the experiments")
    parser.add_argument("--learning-rate", type=float, default=2.5e-4,
                        help="the learning rate of the optimizer")
    parser.add_argument("--buffer-size", type=int, default=10000,
                        help="the replay memory buffer size")
    parser.add_argument("--gamma", type=float, default=0.6,
                        help="the discount factor gamma")
    parser.add_argument("--target-network-frequency", type=int, default=500,
                        help="the timesteps it takes to update the target network")
    parser.add_argument("--batch-size", type=int, default=32,
                        help="the batch size of sample from the reply memory")
    parser.add_argument("--start-e", type=float, default=0.8,
                        help="the starting epsilon for exploration")
    parser.add_argument("--end-e", type=float, default=0.05,
                        help="the ending epsilon for exploration")
    parser.add_argument("--exploration-fraction", type=float, default=0.1,
                        help="the fraction of `total-timesteps` it takes from start-e to go end-e")
    parser.add_argument("--learning-starts", type=int, default=10000,
                        help="timestep to start learning")
    parser.add_argument("--train-frequency", type=int, default=10,
                        help="the frequency of training")
    parser.add_argument("--LEARNING_STEPS", type=int, default=5e4,
                        help="learning steps")
    parser.add_argument("--soft_update_factor", type=float, default=0.1,
                        help="soft_update_factor")
    args = parser.parse_args()
    args.env_id = r"parking"
    return args








def make_env():
    env = gym.make("parking-v0", render_mode="rgb_array")
    env.configure({
        "observation": {
            "type": "KinematicsGoal",
            "features": ["x", "y", "vx", "vy", "cos_h", "sin_h"],
            "scales": [100, 100, 5, 5, 1, 1],
            "normalize": False
        },
        "action": {
            "type": "ContinuousAction",
            "longitudinal": True,
            "lateral": True,
        },

        "duration": 20,  # [s]
        "simulation_frequency": 15,  # [Hz]
        "policy_frequency": 5,  # [Hz]
    })
    env.reset()
    return env

















def linear_schedule(start_e: float, end_e: float, duration: int, t: int):
    """comments:Attenuate epsilon using a linear strategy :epsilon will decay during the time from start_e to end_e"""
    slope = (end_e - start_e) / duration
    return max(slope * t + start_e, end_e)


class action(nn.Module):
    def __init__(self, env):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(np.array(18).prod(), 120),
            nn.ReLU(),
            nn.Linear(120, 84),
            nn.ReLU(),
            nn.Linear(84, (env.action_space.shape)[0]),
        )
    def forward(self, x):
        return self.network(x)

#与action相比，Qnetwork多接收当前的action作为输入，故而输入维度为22
class Q_network(nn.Module):
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(np.array(20).prod(), 120),
            nn.ReLU(),
            nn.Linear(120, 84),
            nn.ReLU(),
            nn.Linear(84, 1),
        )

    def forward(self, x):
        return self.network(x)


if __name__ == "__main__":
    # 变量train：当train为True时，先训练网络，然后展示，否则直接展示结果
    train = False
    """parse the arguments"""

    args = parse_args()
    run_name = f"{args.env_id}__{args.exp_name}__{int(time.time())}"
    env = make_env()

    ###
    """we utilize tensorboard yo log the training process"""
    writer = SummaryWriter(f"runs/{run_name}")
    writer.add_text(
        "hyperparameters",
        "|param|value|\n|-|-|\n%s" % ("\n".join([f"|{key}|{value}|" for key, value in vars(args).items()])),
    )
    ###

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if(train):
        """comments: create a DQN"""
        q_network = Q_network().to(device)
        action_network = action(env).to(device)
        optimizer = optim.Adam(q_network.parameters(), lr=args.learning_rate)
        action_optimizer = optim.Adam(q_network.parameters(), lr=args.learning_rate)
        target_q_network = Q_network().to(device)
        target_q_network.load_state_dict(q_network.state_dict())

        ###
        rb = MyReplayBuffer(args.buffer_size)
        episode_count = 0
        ###

        """comments: Refresh the environment"""
        current_obs = env.reset()
        episode_count+=1
        time_count = 0
        current_obs = current_obs[0]
        for global_step in range(args.total_timesteps):

            """comments: decay the epsilon according to time from start_e to end_e"""
            epsilon = linear_schedule(args.start_e, args.end_e, args.exploration_fraction * args.total_timesteps,
                                      global_step)

            """comments:implementation of epsilon greedy algorithm """

            if random.random() < epsilon:
                actions = env.action_space.sample()
            else:
                network_input = torch.Tensor(
                    current_obs['observation'].tolist() + current_obs['achieved_goal'].tolist() + current_obs[
                    'desired_goal'].tolist()).to(device)
                actions = action_network(network_input).tolist()
            """comments: Run the state and get the results , when the state is run , record the information in the log"""
            next_obs, rewards, dones, truncated, infos = env.step(actions)
            # 3env.render()


            """注意此处obs有两种：obs与current_obs。前者是env接收动作后step输出的状态，
            而后者则是env在reset时输出的状态，它包含step输出的obs和infos两个参数，而我们在Qnetwork中输入的是后者"""
            is_success = infos['is_success']
            rb.add_experience((next_obs, current_obs, rewards, dones, truncated, infos, time_count, is_success, episode_count))

            if(truncated or dones):
                print(f"global_step={global_step}, total_time={args.total_timesteps}, use_time={time_count}, is_success = {infos['is_success']}")
                '''writer.add_scalar("charts/episodic_return", infos["episode"]["r"], global_step)
                writer.add_scalar("charts/episodic_length", infos["episode"]["l"], global_step)'''
                current_obs = env.reset()[0]
                time_count = 0
                episode_count += 1
            else:
                current_obs = next_obs
                time_count+=1

            if global_step > args.learning_starts and global_step % args.train_frequency == 0:
                """comments: choose a batch of data from the data pool"""
                data_batch = rb.sample(args.batch_size)
                episode_count = HER_play_back(rb,data_batch,episode_count) + 1
                """comments: compare the current q value with that of the target network , and calculate the loss"""
                with torch.no_grad():
                    cur_tensor_list = []
                    next_tensor_list = []
                    cur_tensor_for_action_list = []
                    #首先，将当前状态与下一状态需要送入qnetwork中的参数先提取为list方便输入
                    for data in data_batch:
                        next_obs_observation = torch.tensor(data[0]['observation']).to(device)
                        next_obs_achieved_goal = torch.tensor(data[0]['achieved_goal']).to(device)
                        next_obs_desired_goal = torch.tensor(data[0]['desired_goal']).to(device)
                        cur_obs_observation = torch.tensor(data[1]['observation']).to(device)
                        cur_obs_achieved_goal = torch.tensor(data[1]['achieved_goal']).to(device)
                        cur_obs_desired_goal = torch.tensor(data[1]['desired_goal']).to(device)
                        action_to_next = torch.tensor(data[5]['action']).to(device)
                        cur_input_for_action = torch.tensor(data[1]['observation'].tolist() + data[1]['achieved_goal'].tolist() + data[1]['desired_goal'].tolist()).to(device)
                        next_input_for_action = torch.tensor(data[0]['observation'].tolist() + data[0]['achieved_goal'].tolist() + data[0]['desired_goal'].tolist()).to(device)
                        action_to_next_next = action_network(next_input_for_action)
                        cur_input_tensor = torch.cat([cur_obs_observation, cur_obs_achieved_goal, cur_obs_desired_goal, action_to_next]).to(device)
                        next_input_tensor = torch.cat([next_obs_observation, next_obs_achieved_goal, next_obs_desired_goal, action_to_next_next]).to(device)
                        cur_tensor_list.append(cur_input_tensor)
                        next_tensor_list.append(next_input_tensor)
                        cur_tensor_for_action_list.append(cur_input_for_action)
                    cur_input = torch.stack(cur_tensor_list).to(device).float()
                    next_input = torch.stack(next_tensor_list).to(device).float()
                    cur_input_action =torch.stack(cur_tensor_for_action_list).to(device).float()
                #然后计算reward，进而获取q与target_q
                reward_tensor_list = []
                dones_list = []
                for data in data_batch:
                    reward_tensor_list.append(MyReward(data[0],data[6]))
                    if((data[3] == True) or (data[4] == True)):
                        dones_list.append(1)
                    else:
                        dones_list.append(0)
                reward_tensor = torch.tensor(reward_tensor_list)
                reward_tensor = reward_tensor.view(args.batch_size,1).to(device).float()
                dones_tensor = torch.tensor(dones_list)
                dones_tensor = dones_tensor.view(args.batch_size,1).to(device).float()
                q = q_network(cur_input)
                target_q = reward_tensor + (1-dones_tensor) * args.gamma * target_q_network(next_input)

                loss = F.mse_loss(target_q, q)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                new_action_to_next = action_network(cur_input_action)
                cur_tensor_for_action_list = torch.stack(cur_tensor_for_action_list)
                new_cur_input_tensor = torch.cat((cur_tensor_for_action_list, new_action_to_next), dim=1)
                actor_loss = -q_network(new_cur_input_tensor).mean()
                action_optimizer.zero_grad()
                actor_loss.backward()
                action_optimizer.step()

                """comments:update the target_network """
                if global_step % args.target_network_frequency == 0:
                    train_dict = q_network.state_dict()
                    target_dict = target_q_network.state_dict()

                    for param_name, main_param in train_dict.items():
                        target_param = target_dict[param_name]
                        target_param = args.soft_update_factor * main_param + (1 - args.soft_update_factor) * target_param
                        target_dict[param_name] = target_param

                    target_q_network.load_state_dict(target_dict)

        """close the env and tensorboard logger"""
        env.close()
        writer.close()

        ###
        print("yes")
        torch.save(q_network.state_dict(), "parking_her/q_model.pth")
        torch.save(action_network.state_dict(), "parking_her/action_model.pth")
        del q_network
        ##


    model = action(env=env).to(device)
    state_dict = torch.load("parking_her/action_model.pth")
    model.load_state_dict(state_dict)

    '''Test the model'''
    ###
    for episode in range(1000):
        current_obs = env.reset()
        current_obs = current_obs[0]
        done = truncated = False
        while not (done or truncated):
            current_obs = torch.tensor(
                current_obs['observation'].tolist() + current_obs['achieved_goal'].tolist() + current_obs[
                    'desired_goal'].tolist()).to(device)
            action = model(current_obs).tolist()
            obs, reward, done, truncated, info = env.step(action)
            env.render()
            current_obs = obs
    env.close()
    ###
