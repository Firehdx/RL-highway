import random
from queue import Queue
import math
class MyReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def add_experience(self, experience):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        try:
            self.buffer[self.position] = experience
            self.position = (self.position + 1) % self.capacity
        except Exception as e:
            print("The buffer is full , can‘t add much buffer.")

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        return batch

def HER_play_back(buffer, data, add_episode):
    append_buffer = Queue()
    data_reverse = data[::-1]
    for exper in data:
        cur_episode = exper[-1]
        last_obs = cur_episode
        for i in data_reverse:
            if(i[-1] == cur_episode):
                last_obs = i
                break
        if(last_obs[7] == True):
            break
        else:
            new_desire = last_obs[0]['observation']
            add_episode+=1
            for i in data:
                if(i[-1] == cur_episode):
                    new_next_obs = {'observation':i[0]['observation'],'achieved_goal':i[0]['achieved_goal'],'desired_goal':new_desire}
                    new_cur_obs ={'observation':i[1]['observation'],'achieved_goal':i[1]['achieved_goal'],'desired_goal':new_desire}
                    if(i[3] == True):
                        new_exper = (new_next_obs, new_cur_obs, i[2], True, False, i[5], i[6], True, add_episode)
                    else:
                        new_exper = (new_next_obs, new_cur_obs, i[2], i[3], i[4], i[5], i[6], i[7], add_episode)
                    append_buffer.put(new_exper)

    while(append_buffer.empty() == False):
        buffer.add_experience(append_buffer.get())
    return add_episode


def MyReward(obs,cur_time):#停车场的两个界分别是0.31872015和-0.17809531，由于车自身的size，这个值会稍有变化
    reward = 0

    distance_x = abs(obs['observation'][0] - obs['desired_goal'][0])
    distance_y = abs(obs['observation'][1] - obs['desired_goal'][1])
    distance = ((obs['observation'][0] - obs['desired_goal'][0])**2 + (obs['observation'][1] - obs['desired_goal'][1])**2)**0.5

    # 距离reward
    reward -= math.log((distance_x**2 + distance_y**2)**0.5 + 1,1.67158)
    # 速度reward:当距离过远而速度较小时会给予较大惩罚，而距离过近时速度较大会给予较大惩罚
    if(distance_x > 1.2):
        if (abs(obs['observation'][2])<0.8):
            reward-=0.3
    if(distance_y > 0.3):
        if (abs(obs['observation'][3]) < 0.3):
            reward -= 0.1
    if(distance_x < 0.4):
        speed_reward = math.log(abs(obs['observation'][2])+1,1.6)
        distance_weight = -2.5*distance_x + 1
        reward -= speed_reward*distance_weight
    if(distance_y < 0.1):
        speed_reward = math.log(abs(obs['observation'][3]) + 1, 1.3)
        distance_weight = -10 * distance_y + 1
        reward -= speed_reward * distance_weight
    #角度reward:距离近时，引导小车按正确角度停车,给予正奖励
    if(distance<0.29155):
        distance_weight = -3.4299 * distance + 1
        cur_angle = math.radians(math.atan2(obs['observation'][5],obs['observation'][4]))
        desire_angle = math.radians(math.atan2(obs['desired_goal'][5], obs['desired_goal'][4]))
        angle_reward = abs(cur_angle-desire_angle)
        reward += distance_weight*angle_reward
    #距离过近时，给予正奖励
    if(distance<0.3):
        distance_weight = -30 * distance + 3
        reward += distance_weight
    #时间reward：花费时间越大，惩罚越大
    reward -= cur_time*0.1

    #边界reward:在距离边界很近的地方给予巨大的惩罚，以避免小车走入该区域
    if(abs(obs['observation'][0])>0.3):
        reward-=500
    if(abs(obs['observation'][1])>0.16):
        reward-=500
    return reward


