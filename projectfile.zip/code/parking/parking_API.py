import gymnasium as gym
import numpy as np
from stable_baselines3 import HerReplayBuffer, DDPG, DQN, SAC, TD3
from stable_baselines3.her.goal_selection_strategy import GoalSelectionStrategy
import warnings
warnings.filterwarnings("ignore")
def make_env():
    env = gym.make('parking-v0', render_mode="rgb_array")
    env.configure({
        "observation": {
            "type": "KinematicsGoal",
            "features": ["x", "y", "vx", "vy", "cos_h", "sin_h"],
            "scales": [100, 100, 5, 5, 1, 1],
            "normalize": False
        },
        "action": {
            "type": "ContinuousAction",
            "longitudinal": True,
            "lateral": True,
        },

        "duration": 20,  # [s]
        "simulation_frequency": 15,  # [Hz]
        "policy_frequency": 5,  # [Hz]
    })
    env.reset()
    return env

if __name__ == "__main__":
    train = False
    model_class = SAC
    env = make_env()

    if(train):
        goal_selection_strategy = "future"
        model = model_class(
            "MultiInputPolicy",
            env,
            replay_buffer_class=HerReplayBuffer,
            replay_buffer_kwargs=dict(
                n_sampled_goal=4,
                goal_selection_strategy=goal_selection_strategy,
            ),
            verbose=1,
            tensorboard_log="parking_her"
        )
        model.learn(1e5)
        model.save("parking_her/HER_API")

    model = model_class.load("parking_her/HER_API", env=env)
    print("done")

    obs, info = env.reset()
    for _ in range(1000):
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, terminated, truncated, _ = env.step(action)
        env.render()
        if terminated or truncated:
            obs, info = env.reset()


    env.close()