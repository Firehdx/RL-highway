import gymnasium as gym
from stable_baselines3 import PPO
from gymnasium.core import Env
import torch
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import SubprocVecEnv
import eval_intersection
from torch.nn import functional as F
import highway_env  # noqa: F401


ka = 0.4 # 减速惩罚项
kd = 0.3 # 变道惩罚项

class MyWrapper(gym.Wrapper):
    def __init__(self, env: Env, ka, kd):
        super().__init__(env)
        self.ka = ka
        self.kd = kd

    def MyReward(self, action):
        action = torch.tensor(action)
        pa = self.ka * -F.relu(-action[0])
        pd = -abs(self.kd * action[1])
        return pa + pd

    def step(self, action):
        obs, reward, done, truncated, info = self.env.step(action)
        reward = reward + self.MyReward(action)
        return obs, reward, done, truncated, info

if __name__ == "__main__":
    train = False
    if train:
        n_cpu = 8
        batch_size = 64
        env = eval_intersection.env
        env = MyWrapper(env, ka, kd)
        env.configure({
            "observation": {
                "type": "OccupancyGrid",
                "vehicles_count": 15,
                "features": ["presence", "on_road", "x", "y", "vx", "vy", "cos_h", "sin_h"],
                "features_range": {
                    "x": [-100, 100],
                    "y": [-100, 100],
                    "vx": [-20, 20],
                    "vy": [-20, 20]
                },
                "reward_speed_range":[7, 9],
                "grid_size": [[-27.5, 27.5], [-27.5, 27.5]],
                "grid_step": [5, 5],
                "absolute": False
            },
        })
        model = PPO(
            "MlpPolicy",
            env,
            policy_kwargs=dict(net_arch=[dict(pi=[256, 256], vf=[256, 256])]),
            n_steps=batch_size * 12 // n_cpu,
            batch_size=batch_size,
            n_epochs=10,
            learning_rate=1e-4,
            gamma=0.95,
            verbose=0,
            tensorboard_log="intersection_ppo/",
        )
        # Train the agent
        model.learn(total_timesteps=int(20480))
        # Save the agent
        model.save("intersection_ppo/model")

    model = PPO.load("intersection_ppo/model")
    env = eval_intersection.env
    for _ in range(100):
        obs, info = env.reset()
        done = truncated = False
        while not (done or truncated):
            action, _ = model.predict(obs)
            obs, reward, done, truncated, info = env.step(action)
            env.render()