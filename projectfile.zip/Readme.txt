We found that Kinematics observation have a much better performance that OccupancyGrid observation, so we train our model on both of them.
The videos are most recorded in  Kinematics models
Known issue for highway and racetrack models in Kinematics observation: Unexpected keyword argument "use_sde" in custom policy
Can fix by updating your sb3 pkg
https://github.com/DLR-RM/stable-baselines3/issues/168

For parking task:
本文件共包含4种parking的实现方式，分别是DQN\DDPG\DDPG+HER\SAC+HER（使用API）。但是最终提交测试的是第四种实现，即使用sb3库API的SAC+HER方法。该方法的调用方式为：
直接在eval时，from stable_baselines3 import SAC，然后使用model = SAC.load("parking_her/HER_API", env=env)这一段代码将parking_her文件夹种的HER_API.zip参数装载，即可使用该model预测动作。当然，在本文件夹的根文件夹中，已经用eval_parking.py写好了测试环境，可供直接使用。

除此之外，DDPG、DDPG+HER两种方法的模型参数也存放在parking_her文件夹中，但由于效果都很差，故未在eval_parking.py中写入。

最后，DDPG、DDPG+HER、SAC三个模型测试时的视频也都装在parking_her/videos文件夹中，由于本人电脑使用内置录屏软件一直报错，故最终使用电脑录屏。